import React, { useEffect, useState } from "react";
import ProductCard from "../component/ProductCard";

function ProductAll() {
  const [productList, setProductList] = useState([]);
  const getProducts = async () => {
    let url = `http://localhost:3004/products`;
    let response = await fetch(url);
    let data = await response.json();
    console.log(data);
    setProductList(data);
  };
  //useEffect(()=>{},[])//[]이 비어있으면 component가 실행될때 한번만 실행
  //useEffect(()=>{},[변수])//[]에 변수가 있으면 component가 실행될때 한번 실행하고 변수값이 바뀔때마다 함수가 실행
  useEffect(() => {
    getProducts();
  }, []);

  return (
    <div>
      <div className="cards">
        {productList.map((menu) => {
          return <ProductCard key={menu.id} item={menu} />;
        })}
      </div>
    </div>
  );
}

export default ProductAll;
